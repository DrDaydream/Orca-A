#!/usr/bin/env python3
"""Serial calls to existing fab remote tasks, with immutable attempt archives.

For each protocol and node count: create an exact-size private pool, install,
run and archive pending cases, then destroy it. Each case runs once for 100 measured
seconds. Failures stop the batch after cleanup. No repository edits are made.
"""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import shutil
import signal
from statistics import fmean
import subprocess
import sys
import time

PROTOCOLS = {
    'Orca-A': 'Orca-A/benchmark',
    'Orca-B': 'Orca-B-grbc/benchmark',
    'Bullshark': 'narwhal-bullshark-ubuntu24/benchmark',
    'Mysticeti': 'mysticeti/benchmark',
    'Mahi-Mahi': 'mahi-mahi-ubuntu24/aws',
}
MODES = ('A0', 'A1', 'A3', 'A5')
NODES = (10, 20, 35)
RATES = (10000, 30000, 50000, 70000, 90000, 110000, 130000, 150000)
NATIVE_MODES = dict(A0='none', A1='silent', A3='targeted', A5='network')
DURATION = 100
SEED = 7
V21_POOL_TOOLS = dict(
    wrapper_sha256='374bf3e2feaa039a738a7e7d5945684b82b46da1bc49b61f415750cba7673cd0',
    lifecycle_sha256='ff6c7e789bfbaa9f5b91a0efc974b8560023b632c6e761f1a57462af5428b678',
    protocol_tasks_sha256='1707147f9e6d77ee036a4df288f153fddf6efcf14d584a88478c3585700c590e',
)
V3_POOL_TOOLS = dict(V21_POOL_TOOLS,
    wrapper_sha256='f8ec4c60363e5b55ccb91902c84942990aadb2d0025df46f18e5248dbaec85df',
    lifecycle_sha256='1b5664d2ef967d3db898ab5281962f54f92a46e8055be3ef2b0d6c2a518035ee')
# These reviewed commits only change installation/run orchestration, tests and
# documentation. Native code, build flags, metrics and fabfile parameters match.
INSTALL_ONLY_REVISIONS = {
    'Orca-A': ('8867523992a04a0e9433364db559af3977b03201', '57a6ccc0b4a0ce21baa59081192bc8bb5f0208ba'),
    'Orca-B': ('1e88708380fcf4de8a7a5b47da5ca79fdda769fb', 'a970a8d6bec6198658f23eef6090e6332b43b0eb'),
}
PREBUILT_REMOTE_SHA256 = {
    'Orca-A': '34f381d4a2d650fc4eb3a268af7be757d2cd37ac345337d7bcab09b11194a9f0',
    'Orca-B': '80e3fa65c66cbf5e94b4101f710889acaeeea2be60543b5c596c90ac9fd5650e',
}


def save(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                   allow_nan=False) + '\n', encoding='utf-8')
    temporary.replace(path)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def nearby_rate(target, nodes):
    # Common quantum: legacy clients use 20 bursts/s; shared generators use 10.
    quantum = 20 * nodes
    return ((target + quantum // 2) // quantum) * quantum


def cases(protocol='all', mode='all'):
    for name in PROTOCOLS if protocol == 'all' else [protocol]:
        for nodes in NODES:
            for attack in MODES if mode == 'all' else [mode]:
                for target in RATES:
                    yield dict(protocol=name, mode=attack, nodes=nodes,
                               nominal_rate_tps=target, input_rate_tps=nearby_rate(target, nodes),
                               byzantine=0 if attack == 'A0' else (nodes - 1) // 3,
                               repetition=1, duration_s=DURATION, warmup_s=0, seed=SEED)


def case_key(case):
    return f"{case['protocol']}/{case['mode']}/n{case['nodes']}/r{case['input_rate_tps']}"


def shared(case):
    return case['protocol'] in ('Mysticeti', 'Mahi-Mahi')


def command(case, settings_path=None):
    result = ['fab', 'remote', '--nodes', str(case['nodes']), '--rate',
              str(case['input_rate_tps']), '--tx-size', '512', '--duration',
              str(DURATION), '--runs', '1', '--faults', '0', '--adversary', case['mode']]
    if case['byzantine']:
        result += ['--byzantine', str(case['byzantine'])]
    if shared(case):
        result += ['--warmup', '0', '--scrape-interval', '5', '--settings', str(settings_path)]
    else:
        result += ['--workers', '1', '--seed', str(SEED), '--start-round', '1',
                   '--attack-rounds', '0', '--delay-ms', '200',
                   '--max-pending-messages', '4096', '--max-pending-bytes', '67108864']
        if case['protocol'] == 'Bullshark':
            result += ['--bullshark-alternating', 'false' if case['mode'] == 'A0' else 'true']
    return result


def effective_settings(source, case):
    settings = read(source)
    # Use a separate settings file outside the Git checkout. Infrastructure
    # configuration is retained, while experimental variables are explicit.
    key = settings.get('key', {})
    if key.get('path'):
        path = Path(key['path']).expanduser()
        key['path'] = str((source.parent / path).resolve() if not path.is_absolute() else path)
    settings.setdefault('benchmark', {}).update(
        nodes=case['nodes'], rate=case['input_rate_tps'], duration=DURATION,
        warmup=0, runs=1, faults=0, tx_size=512, scrape_interval=5,
        enable_synchronizer=True, leader_schedule='round_robin',
        leaders=4 if case['protocol'] == 'Mahi-Mahi' else 2,
        wave_length=5 if case['protocol'] == 'Mahi-Mahi' else 3,
        leader_timeout_ms=250 if case['protocol'] == 'Mahi-Mahi' else 1000,
        adversary=dict(mode=case['mode'], byzantine_authorities=list(range(case['byzantine'])),
                       seed=SEED, start_after_ms=20000, duration_ms=60000,
                       delay_ms=200, late_delay_ms=1000, max_pending_messages=4096,
                       max_pending_bytes=67108864, max_extra_bytes_per_round=8388608,
                       target_authority=None, target_round=None))
    return settings


def load_module(path):
    spec = importlib.util.spec_from_file_location('saved_measurement_parser', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest_files(directory, pattern):
    return {p.name: sha(p) for p in directory.glob(pattern) if p.is_file()}


def summarize_replicas(rows):
    honest = [r for r in rows if not r['byzantine']]
    positive = [r for r in honest if r['latency_ms'] is not None]
    return dict(latency_ms=fmean(r['latency_ms'] for r in positive) if positive else None,
                latency_contributors=len(positive), honest_replicas=len(honest),
                zero_commit_replicas=[r['authority'] for r in honest if r['completed'] == 0],
                replica_aggregation='unweighted mean of honest positive-observation replica means',
                replicas=rows)


def legacy_measurement(archive, case):
    logs = archive / 'logs'
    clients = sorted(logs.glob('client-*.log'))
    workers = sorted(logs.glob('worker-*.log'))
    primaries = sorted(logs.glob('primary-*.log'))
    required = case['nodes']
    if not (len(clients) == len(workers) == len(primaries) == required):
        raise ValueError('Incomplete log set (expected one client, worker and primary per node)')
    if [p.name.removeprefix('client-') for p in clients] != [p.name.removeprefix('worker-') for p in workers]:
        raise ValueError('Client/worker log identities do not match')
    if sorted(int(p.stem.split('-')[1]) for p in primaries) != list(range(required)):
        raise ValueError('Primary identities do not cover the committee')
    texts = [[p.read_text(encoding='utf-8', errors='replace') for p in paths]
             for paths in (clients, primaries, workers)]
    if any(re.search(r'panicked at|thread .* panicked', t) for group in texts for t in group):
        raise ValueError('A process panicked; inspect archived logs')
    measure = load_module(archive / 'measurement_parser.py').Measurements(*texts)
    measure.replica_logs = [p.name for p in primaries]
    measure.source_logs = [dict(client=c.name, worker=w.name) for c, w in zip(clients, workers)]
    metrics = measure.metrics(duration=DURATION, warmup=0, drain=0)
    save(archive / 'measurement_stats.json', metrics)
    if metrics['status'] != 'available':
        raise ValueError('Release/ingress instrumentation is incomplete; latency is not comparable')
    rows = []
    for path, row in zip(primaries, metrics['replicas']):
        if row['invalid_time_samples'] or row['missing_ingress_samples']:
            raise ValueError('Invalid clock ordering or missing ingress: inspect measurement_stats.json')
        ident = int(path.stem.split('-')[1])
        rows.append(dict(authority=ident, byzantine=ident < case['byzantine'],
                         completed=row['completed_samples'], released=row['released_samples'],
                         unfinished=row['unfinished_samples'],
                         completion_ratio=row['completion_ratio'],
                         latency_ms=row['release_to_final']['mean_ms'],
                         latency_observations=row['release_to_final']['count']))
    result = summarize_replicas(rows)
    result.update(metric='release_to_final_ms', completion_population='sampled transactions per replica',
                  window_basis='release cohort [first client Start, Start + 100s); final commit by cutoff',
                  zero_commit_meaning='no completed sampled transaction (not proof of no commits)',
                  attack_window='round 1 onward' if case['mode'] != 'A0' else 'disabled',
                  bullshark_alternating=case['protocol'] == 'Bullshark' and case['mode'] != 'A0')
    return result


def shared_measurement(archive, case):
    native = archive / 'native'
    record = read(native / 'run.json')
    if record['status'] != 'complete' or record.get('log_errors') or record.get('cleanup_errors'):
        raise ValueError('Native run is incomplete or log collection/cleanup failed')
    params = record['parameters']
    for key, expected in [('nodes', case['nodes']), ('rate', case['input_rate_tps']),
                          ('duration', DURATION), ('warmup', 0), ('faults', 0), ('runs', 1)]:
        if params.get(key) != expected:
            raise ValueError(f'Native run parameter mismatch: {key}')
    attack = record['adversary']
    if attack['mode'] != case['mode'] or sorted(attack['byzantine_authorities']) != list(range(case['byzantine'])):
        raise ValueError('Native adversary differs from requested case')
    windows = {}
    for line in (native / 'samples.jsonl').read_text(encoding='utf-8').splitlines():
        sample = json.loads(line)
        if sample['phase'] in ('before', 'after'):
            if sample['phase'] in windows:
                raise ValueError('Multiple full-run windows')
            windows[sample['phase']] = sample['nodes']
    if set(windows) != {'before', 'after'}:
        raise ValueError('No complete before/after window')
    before, after = windows['before'], windows['after']
    if set(before) != {str(i) for i in range(case['nodes'])} or set(after) != set(before):
        raise ValueError('Incomplete replica scrape set')
    summary = load_module(archive / 'measurement_parser.py').summarize(
        {i: s['metrics'] for i, s in before.items()},
        {i: s['metrics'] for i, s in after.items()},
        {i: after[i]['monotonic'] - s['monotonic'] for i, s in before.items()})
    save(archive / 'measurement_stats.json', summary)
    rows = [dict(authority=int(r['authority']), byzantine=int(r['authority']) < case['byzantine'],
                 completed=r['committed_transactions'], released=None, unfinished=None,
                 completion_ratio=None, latency_ms=r['mean_latency_ms'],
                 duration_s=r['duration_s'], tps=r['tps'], fork_output_ratio=r.get('fork_output_ratio'))
            for r in summary['nodes']]
    result = summarize_replicas(rows)
    result.update(metric='shared_commit_ms', source_commit=record.get('commit'),
                  completion_population='committed transaction entries (fork payloads not deduplicated)',
                  window_basis='commit histogram delta after readiness; 100s plus scrape overhead',
                  zero_commit_meaning='no committed transaction entries in measurement window',
                  attack_window='20s..80s after each node initializes' if case['mode'] != 'A0' else 'disabled',
                  bullshark_alternating=False)
    return result


def copy_native(source, destination):
    destination.mkdir()
    # Keep reproducible public evidence. Genesis directories can contain keys.
    for name in ('run.json', 'samples.jsonl', 'summary.json', 'summary.csv', 'summary.txt'):
        if (source / name).is_file():
            shutil.copy2(source / name, destination / name)
    for name in ('logs', 'metrics'):
        if (source / name).is_dir():
            shutil.copytree(source / name, destination / name)
    for name in ('committee.yaml', 'parameters.yaml', 'public-config.yaml', 'client-parameters.yaml'):
        for path in (source / name, source / 'genesis' / name):
            if path.is_file():
                shutil.copy2(path, destination / name)


def run_case(case, bench, output, retry_failed=False, lifecycle=None):
    directory = output / case_key(case)
    directory.mkdir(parents=True, exist_ok=True)
    selected = directory / 'selected.json'
    if selected.is_file():
        old = read(selected)
        if old['case'] != case:
            raise ValueError(f'Existing configuration differs: {selected}')
        if old['status'] == 'complete':
            print(f'SKIP completed: {case_key(case)}', flush=True)
            return
        if not retry_failed:
            raise RuntimeError(f'Previous attempt failed: {directory}. Inspect it, then use --retry-failed.')
    archive = directory / datetime.now(timezone.utc).strftime('attempt-%Y%m%dT%H%M%S.%fZ')
    archive.mkdir()
    meta = dict(case=case, status='running', attempt=str(archive.name), started_utc=datetime.now(timezone.utc).isoformat())
    save(selected, meta)
    save(archive / 'metadata.json', meta)
    native_before = {p.name for p in (bench / 'results').glob('run-*') if p.is_dir()}
    logs_before = digest_files(bench / 'logs', '*.log') if not shared(case) else {}
    results_before = digest_files(bench / 'results', '*') if not shared(case) else {}
    configuration = archive / 'effective-settings.json'
    if shared(case):
        source = lifecycle.settings_path if lifecycle else bench / 'settings.json'
        save(configuration, effective_settings(source, case))
    cmd = command(case, configuration)
    if lifecycle:
        cmd = lifecycle.wrap(cmd)
        meta['testbed_scope'] = lifecycle.record['scope']
    meta['command'] = shlex.join(cmd)
    meta['cwd'] = str(bench)
    meta['controller_commit'] = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=bench, text=True).strip()
    meta['controller_git_status'] = subprocess.check_output(
        ['git', 'status', '--porcelain'], cwd=bench, text=True)
    save(archive / 'metadata.json', meta)
    (archive / 'command.txt').write_text(f'cd {shlex.quote(str(bench))}\n{shlex.join(cmd)}\n', encoding='utf-8')
    print(f'RUN {case_key(case)}\n{shlex.join(cmd)}', flush=True)
    interrupted = False
    returncode = -1
    try:
        with (archive / 'console.log').open('w', encoding='utf-8') as log:
            process_options = dict(env=lifecycle.env) if lifecycle else {}
            process = subprocess.Popen(cmd, cwd=bench, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, errors='replace', bufsize=1,
                                       **process_options)
            try:
                for line in process.stdout:
                    print(line, end='', flush=True)
                    log.write(line)
                    log.flush()
                returncode = process.wait()
            except KeyboardInterrupt:
                interrupted = True
                # Wait for the foreground Fabric process to exit before releasing
                # the global lock; never start another case concurrently.
                process.terminate()
                try:
                    process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                raise
        meta['returncode'] = returncode
        if shared(case):
            runs = [p for p in (bench / 'results').glob('run-*') if p.is_dir() and p.name not in native_before]
            if len(runs) != 1:
                raise ValueError(f'Expected exactly one new native run directory; found {len(runs)}')
            copy_native(runs[0], archive / 'native')
            package = 'mysticeti_aws' if case['protocol'] == 'Mysticeti' else 'mahi_aws'
            shutil.copy2(bench / package / 'metrics.py', archive / 'measurement_parser.py')
            if returncode:
                raise ValueError(f'fab remote exited with {returncode}')
            measurement = shared_measurement(archive, case)
        else:
            if (bench / 'logs').is_dir():
                shutil.copytree(bench / 'logs', archive / 'logs')
            raw = archive / 'native-results'
            raw.mkdir()
            changed = []
            for name, digest in digest_files(bench / 'results', '*').items():
                if results_before.get(name) != digest:
                    shutil.copy2(bench / 'results' / name, raw / name)
                    changed.append(name)
            shutil.copy2(bench / 'benchmark' / 'measurements.py', archive / 'measurement_parser.py')
            fresh = digest_files(bench / 'logs', '*.log')
            if not fresh or any(logs_before.get(name) == digest for name, digest in fresh.items()):
                raise ValueError('Missing or unchanged logs; refusing to reuse stale results')
            snapshots = [read(raw / n) for n in changed if n.endswith('.parameters.json')]
            if len(snapshots) != 1:
                raise ValueError('Missing or ambiguous per-run parameters snapshot')
            snapshot = snapshots[0]
            if snapshot['nodes'] != case['nodes'] or snapshot['rate'] != case['input_rate_tps'] or snapshot['adversary']['mode'] != NATIVE_MODES[case['mode']]:
                raise ValueError('Archived parameter snapshot does not match requested case')
            if returncode:
                raise ValueError(f'fab remote exited with {returncode}')
            measurement = legacy_measurement(archive, case)
        measurement.update(case=case, status='complete', archive=str(archive),
                           controller_commit=meta['controller_commit'])
        if lifecycle:
            measurement['testbed_scope'] = lifecycle.record['scope']
        save(archive / 'measurement.json', measurement)
        latency = measurement['latency_ms']
        lines = [case_key(case), f'Status: complete',
                 f'Latency metric: {measurement["metric"]}',
                 f'Honest replica mean latency (ms): {latency if latency is not None else "N/A"}',
                 f'Latency contributors: {measurement["latency_contributors"]}/{measurement["honest_replicas"]}',
                 f'Zero completed observations at replicas: {measurement["zero_commit_replicas"]}',
                 f'Archive: {archive}']
        (archive / 'summary.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
        meta['status'] = 'complete'
    except BaseException as error:
        meta.update(status='interrupted' if interrupted else 'failed', error=str(error), returncode=returncode)
        # Save evidence already downloaded by the native task before the
        # lifecycle finally terminates the pool, including early interrupts.
        try:
            if shared(case) and not (archive / 'native').exists():
                candidates = [p for p in (bench / 'results').glob('run-*') if p.is_dir() and p.name not in native_before]
                if len(candidates) == 1:
                    copy_native(candidates[0], archive / 'native')
            elif not shared(case) and not (archive / 'logs').exists() and (bench / 'logs').is_dir():
                shutil.copytree(bench / 'logs', archive / 'logs')
                meta['logs_require_freshness_check'] = True
        except Exception as archive_error:
            meta['archive_error'] = str(archive_error)
        raise
    finally:
        meta['finished_utc'] = datetime.now(timezone.utc).isoformat()
        save(archive / 'metadata.json', meta)
        save(selected, meta)
        files = {str(p.relative_to(archive)): sha(p) for p in sorted(archive.rglob('*')) if p.is_file() and p.name != 'SHA256.json'}
        save(archive / 'SHA256.json', files)


def plan_file(plan, output):
    output.mkdir(parents=True, exist_ok=True)
    with (output / 'experiment-matrix.csv').open('w', newline='', encoding='utf-8-sig') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(plan[0]))
        writer.writeheader()
        writer.writerows(plan)


def require_prebuilt_remote(name, bench):
    """Reject the old Orca auto-install path before allocating any instances."""
    if name not in PREBUILT_REMOTE_SHA256:
        return
    path = bench / 'benchmark' / 'remote.py'
    try:
        digest = hashlib.sha256(path.read_text(encoding='utf-8').encode('utf-8')).hexdigest()
    except OSError as error:
        raise ValueError(f'{name}: missing remote runner at {path}') from error
    if digest != PREBUILT_REMOTE_SHA256[name]:
        raise ValueError(f'{name}: update the controller repository to the published install-only '
                         f'revision {INSTALL_ONLY_REVISIONS[name][1]} before running this toolkit')


def upgrade_pool_policy(output, campaign, current):
    """Checked v2.1/v3 migration and reviewed install-only source transitions."""
    changed = [name for name in campaign if campaign[name] != current.get(name)]
    if not changed:
        return {**campaign, **current}
    revisions = {}
    releases = set()
    for name in changed:
        old, new = campaign[name], current.get(name)
        old_tools = {key: old.get(key) for key in V21_POOL_TOOLS}
        if new is None or old_tools not in (V21_POOL_TOOLS, V3_POOL_TOOLS,
                                           {key: new.get(key) for key in V21_POOL_TOOLS}):
            raise ValueError(f'{name}: only released v2.1/v3 or current tools can be upgraded in place')
        releases.add('v2.1' if old_tools == V21_POOL_TOOLS else 'v3' if old_tools == V3_POOL_TOOLS else 'current')
        stable_old = {key: value for key, value in old.items() if key not in V21_POOL_TOOLS}
        stable_new = {key: value for key, value in new.items() if key not in V21_POOL_TOOLS}
        if old.get('commit') != new.get('commit'):
            pair = (old.get('commit'), new.get('commit'))
            if INSTALL_ONLY_REVISIONS.get(name) != pair:
                raise ValueError(f'{name}: source commit change is not an approved install-only update')
            stable_old['commit'] = stable_new['commit']
            revisions[name] = dict(previous=pair[0], current=pair[1], reason='install-only orchestration update')
        if stable_old != stable_new or new.get('protocol_tasks_sha256') != V21_POOL_TOOLS['protocol_tasks_sha256']:
            raise ValueError(f'{name}: source/settings/native tasks changed; cannot reuse this campaign')
    for path in output.glob('lifecycle/*/state.json'):
        if read(path).get('status') != 'terminated':
            raise ValueError(f'Finish cleanup with the old output directory before upgrading: {path}')
    expected = {case_key(case): case for case in cases()}
    completed = 0
    for path in output.glob('*/*/n*/r*/selected.json'):
        try:
            selected = read(path)
            key = path.parent.relative_to(output).as_posix()
            if selected.get('case') != expected.get(key) or key not in expected:
                raise ValueError(f'Existing case parameters differ: {path}')
            if selected.get('status') != 'complete':
                continue
            attempt = selected['attempt']
            if Path(attempt).name != attempt or not attempt.startswith('attempt-'):
                raise ValueError(f'Invalid completed attempt path: {path}')
            archive = path.parent / attempt
            measurement = archive / 'measurement.json'
            result = read(measurement)
            if result.get('status') != 'complete' or result.get('case') != selected['case']:
                raise ValueError(f'Completed measurement does not match selected case: {measurement}')
            if read(archive / 'SHA256.json').get('measurement.json') != sha(measurement):
                raise ValueError(f'Completed measurement hash differs: {measurement}')
            completed += 1
        except (OSError, KeyError, TypeError, json.JSONDecodeError) as error:
            raise ValueError(f'Cannot reuse completed measurement at {path}: {error}') from error
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    backup = output / f'campaign.before-node-pools-{stamp}.json'
    save(backup, campaign)
    save(output / f'pool-policy-upgrade-{stamp}.json', dict(
        from_releases=sorted(releases), to_release='v3.1',
        to_policy='one exact-size pool per protocol/node count; install once, reuse binaries for remote',
        approved_source_updates=revisions,
        completed_cases_preserved=completed, previous_campaign=backup.name,
        protocols=changed, upgraded_utc=datetime.now(timezone.utc).isoformat()))
    print(f'Pool/install policy upgraded; preserving {completed} completed cases. Backup: {backup}', flush=True)
    return {**campaign, **current}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol', choices=['all', *PROTOCOLS], default='all')
    parser.add_argument('--mode', choices=['all', *MODES], default='all')
    parser.add_argument('--root', type=Path, default=Path('/home/ubuntu/experiments'))
    parser.add_argument('--output', type=Path, default=Path('/home/ubuntu/experiments/paper-results'))
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--retry-failed', action='store_true')
    parser.add_argument('--upgrade-pool-policy', action='store_true',
                        help='Reuse verified v2.1/v3 results after cleanup; allow only reviewed pool/install changes')
    parser.add_argument('--cleanup-only', action='store_true', help='Destroy only recorded unfinished batch pools; never create or run')
    args = parser.parse_args()
    plan = list(cases(args.protocol, args.mode))
    output = args.output.resolve()
    print('Cleanup recorded batch pools only; no create/install/remote.' if args.cleanup_only else
          f'{len(plan)} configurations; one run each; 100 measured seconds; warmup=0; strictly serial.')
    if args.dry_run:
        plan_file(list(cases()), output)
        from lifecycle import instances_per_region, regions
        for name in dict.fromkeys(c['protocol'] for c in plan):
            bench = args.root / PROTOCOLS[name]
            protocol_plan = [c for c in plan if c['protocol'] == name]
            for nodes in sorted({case['nodes'] for case in protocol_plan}):
                size_plan = [case for case in protocol_plan if case['nodes'] == nodes]
                count = (instances_per_region(nodes, regions(bench))
                         if (bench / 'settings.json').is_file() else f'<{nodes}/configured-regions; exact division required>')
                print(f'\n[{name} n={nodes}] exactly {nodes} instances; private scope; cwd={bench}')
                print('# FIGURE_SCOPE and scoped settings are generated during execution; this plan does not create them.')
                prefix = ['fab', '-r', str(Path(__file__).resolve().parent), '-c', 'protocol_tasks']
                scope_settings = (['--settings', str(output / 'lifecycle' / name / f'SCOPE-n{nodes}/settings.json')]
                                  if name in ('Mysticeti', 'Mahi-Mahi') else [])
                print(shlex.join(prefix + ['create', '--nodes', str(count)] + scope_settings))
                print('# Verify exact running instance inventory')
                if name not in ('Mysticeti', 'Mahi-Mahi'):
                    print(shlex.join(prefix + ['ready']))
                print(shlex.join(prefix + ['install'] + scope_settings))
                for case in size_plan:
                    settings = output / case_key(case) / 'attempt-TIMESTAMP/effective-settings.json'
                    print(shlex.join(prefix + command(case, settings)[1:]))
                print('# All results archived, or exception/interrupt cleanup')
                print(shlex.join(prefix + ['destroy'] + scope_settings))
                print('# Verify batch inventory is empty before the next node count or protocol')
        return
    if sys.platform != 'linux':
        parser.error('Execute on the Ubuntu EC2 controller. Dry-run and plotting also work on Windows.')
    if not shutil.which('fab'):
        parser.error('fab is not on PATH; activate the Fabric Python environment first')
    if not args.cleanup_only and importlib.util.find_spec('matplotlib') is None:
        parser.error('Install matplotlib in this Python environment before running the matrix')
    from lifecycle import ProtocolLifecycle, run_protocol
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))
    import fcntl
    # A controller-wide lock also covers separate output directories and protocols.
    with Path('/tmp/five-protocol-figure-matrix.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            parser.error('Another five-protocol matrix is running on this controller')
        if args.cleanup_only:
            for name in dict.fromkeys(c['protocol'] for c in plan):
                ProtocolLifecycle(name, args.root / PROTOCOLS[name], output).recover()
            return
        campaign_path = output / 'campaign.json'
        campaign = read(campaign_path) if campaign_path.is_file() else {}
        identities = {}
        for name in dict.fromkeys(c['protocol'] for c in plan):
            bench = args.root / PROTOCOLS[name]
            if not (bench / 'fabfile.py').is_file() or not (bench / 'settings.json').is_file():
                parser.error(f'Missing fabfile.py/settings.json in {bench}; complete setup first')
            try:
                require_prebuilt_remote(name, bench)
            except ValueError as error:
                parser.error(str(error))
            identity = dict(commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=bench, text=True).strip(),
                            settings_sha256=sha(bench / 'settings.json'),
                            fabfile_sha256=sha(bench / 'fabfile.py'),
                            wrapper_sha256=sha(Path(__file__)),
                            lifecycle_sha256=sha(Path(__file__).with_name('lifecycle.py')),
                            protocol_tasks_sha256=sha(Path(__file__).with_name('protocol_tasks.py')))
            if not args.upgrade_pool_policy and name in campaign and campaign[name] != identity:
                parser.error(f'{name} source/settings/tools changed since this batch began; use a new --output directory')
            identities[name] = identity
        output.mkdir(parents=True, exist_ok=True)
        if args.upgrade_pool_policy:
            if args.protocol != 'all' or args.mode != 'all':
                parser.error('--upgrade-pool-policy requires the full protocol/mode selection')
            try:
                campaign = upgrade_pool_policy(output, campaign, identities)
            except ValueError as error:
                parser.error(str(error))
        else:
            campaign.update(identities)
        save(campaign_path, campaign)
        plan_file(list(cases()), output)
        for name in dict.fromkeys(c['protocol'] for c in plan):
            protocol_plan = [c for c in plan if c['protocol'] == name]
            run_protocol(protocol_plan, args.root / PROTOCOLS[name], output, run_case, args.retry_failed)
    subprocess.run([sys.executable, str(Path(__file__).with_name('plot_figures.py')), str(output)], check=True)


if __name__ == '__main__':
    main()
