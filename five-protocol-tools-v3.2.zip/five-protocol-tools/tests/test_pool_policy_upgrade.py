"""Allow the known v2.1 resource-policy upgrade without mixing changed experiments."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import run_matrix as matrix

V21 = dict(wrapper_sha256='374bf3e2feaa039a738a7e7d5945684b82b46da1bc49b61f415750cba7673cd0',
           lifecycle_sha256='ff6c7e789bfbaa9f5b91a0efc974b8560023b632c6e761f1a57462af5428b678',
           protocol_tasks_sha256='1707147f9e6d77ee036a4df288f153fddf6efcf14d584a88478c3585700c590e')


class UpgradeTests(unittest.TestCase):
    def records(self, root):
        before = {name: dict(commit=f'{name}-source', settings_sha256='settings', fabfile_sha256='native-fab', **V21)
                  for name in matrix.PROTOCOLS}
        after = copy.deepcopy(before)
        for identity in after.values():
            identity.update(wrapper_sha256='new-wrapper', lifecycle_sha256='new-lifecycle')
        for name in matrix.PROTOCOLS:
            path = root / 'lifecycle' / name / 'state.json'
            path.parent.mkdir(parents=True)
            matrix.save(path, {'status': 'terminated', 'creation_started': True})
        matrix.save(root / 'campaign.json', before)
        return before, after

    def completed(self, root, mode='A0'):
        case = next(matrix.cases('Orca-A', mode))
        path = root / matrix.case_key(case) / 'selected.json'
        path.parent.mkdir(parents=True)
        matrix.save(path, {'case': case, 'status': 'complete', 'attempt': 'attempt-fixture'})
        archive = path.parent / 'attempt-fixture'
        archive.mkdir()
        matrix.save(archive / 'measurement.json', {'status': 'complete', 'case': case, 'latency_ms': 123})
        matrix.save(archive / 'SHA256.json', {'measurement.json': matrix.sha(archive / 'measurement.json')})
        return path, archive

    def invoke(self, *args):
        self.assertTrue(hasattr(matrix, 'upgrade_pool_policy'), 'Missing checked v2.1 policy migration')
        return matrix.upgrade_pool_policy(*args)

    def test_known_policy_upgrade_preserves_completed_results_and_original_campaign(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            before, after = self.records(root)
            selected, archive = self.completed(root)
            original = selected.read_bytes(), (archive / 'measurement.json').read_bytes()
            result = self.invoke(root, before, after)
            self.assertEqual(result, after)
            self.assertEqual(original, (selected.read_bytes(), (archive / 'measurement.json').read_bytes()))
            backups = list(root.glob('campaign.before-node-pools-*.json'))
            self.assertEqual(len(backups), 1)
            self.assertEqual(matrix.read(backups[0]), before)

    def test_changes_to_source_settings_native_tasks_or_unknown_wrapper_are_rejected(self):
        for field in ('commit', 'settings_sha256', 'fabfile_sha256', 'wrapper_sha256', 'protocol_tasks_sha256'):
            with self.subTest(field=field), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                before, after = self.records(root)
                if field in ('wrapper_sha256', 'protocol_tasks_sha256'):
                    before['Orca-A'][field] = 'unrecognized-old-tool'
                else:
                    after['Orca-A'][field] = 'different-experiment'
                with self.assertRaises(ValueError):
                    self.invoke(root, before, after)
                self.assertFalse(list(root.glob('campaign.before-node-pools-*.json')))

    def test_unfinished_instance_pool_refuses_upgrade(self):
        for status in ('running', 'destroying', 'cleanup_failed', 'failed'):
            with self.subTest(status=status), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                before, after = self.records(root)
                matrix.save(root / 'lifecycle/Orca-A/state.json', {'status': status})
                with self.assertRaisesRegex(ValueError, 'cleanup'):
                    self.invoke(root, before, after)

    def test_modified_case_or_missing_measurement_refuses_reuse(self):
        for broken in ('case', 'missing', 'hash'):
            with self.subTest(broken=broken), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                before, after = self.records(root)
                selected, archive = self.completed(root)
                if broken == 'case':
                    data = matrix.read(selected)
                    data['case']['duration_s'] = 999
                    matrix.save(selected, data)
                elif broken == 'missing':
                    (archive / 'measurement.json').unlink()
                else:
                    data = matrix.read(archive / 'measurement.json')
                    data['latency_ms'] = 456
                    matrix.save(archive / 'measurement.json', data)
                with self.assertRaises(ValueError):
                    self.invoke(root, before, after)

    def test_unchanged_current_campaign_is_idempotent(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            before, after = self.records(root)
            self.assertEqual(self.invoke(root, after, after), after)
            self.assertFalse(list(root.glob('campaign.before-node-pools-*.json')))

    def test_reviewed_install_only_commits_can_reuse_v21_and_v3_results(self):
        pairs = {
            'Orca-A': ('8867523992a04a0e9433364db559af3977b03201', '57a6ccc0b4a0ce21baa59081192bc8bb5f0208ba'),
            'Orca-B': ('1e88708380fcf4de8a7a5b47da5ca79fdda769fb', 'a970a8d6bec6198658f23eef6090e6332b43b0eb'),
        }
        v3 = dict(V21, wrapper_sha256='f8ec4c60363e5b55ccb91902c84942990aadb2d0025df46f18e5248dbaec85df',
                  lifecycle_sha256='1b5664d2ef967d3db898ab5281962f54f92a46e8055be3ef2b0d6c2a518035ee')
        for release in (V21, v3):
            with self.subTest(release=release), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                before, after = self.records(root)
                for name, (old, new) in pairs.items():
                    before[name].update(release, commit=old)
                    after[name]['commit'] = new
                selected, archive = self.completed(root)
                original = selected.read_bytes(), (archive / 'measurement.json').read_bytes()
                self.assertEqual(self.invoke(root, before, after), after)
                self.assertEqual(original, (selected.read_bytes(), (archive / 'measurement.json').read_bytes()))

    def test_install_only_revision_does_not_allow_changed_experiment_settings(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            before, after = self.records(root)
            before['Orca-A']['commit'] = '8867523992a04a0e9433364db559af3977b03201'
            after['Orca-A']['commit'] = '57a6ccc0b4a0ce21baa59081192bc8bb5f0208ba'
            after['Orca-A']['settings_sha256'] = 'changed-region-or-parameters'
            with self.assertRaises(ValueError):
                self.invoke(root, before, after)

    def test_v31_native_silent_summary_update_preserves_honest_plot_measurements(self):
        pairs = {
            'Orca-A': ('57a6ccc0b4a0ce21baa59081192bc8bb5f0208ba', 'c617ac3cfeb69a0dd32ca096ca53c8d62cbb6a83'),
            'Orca-B': ('a970a8d6bec6198658f23eef6090e6332b43b0eb', '015346bb6e57af916ec9a0c698d7e34f0236a7a8'),
        }
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            before, after = self.records(root)
            for name in matrix.PROTOCOLS:
                before[name].update(wrapper_sha256='f70843f95fa055bdd2142737061e8a32df33cdddc54a9b0698f7ac52984d8251',
                                    lifecycle_sha256='1b5664d2ef967d3db898ab5281962f54f92a46e8055be3ef2b0d6c2a518035ee')
            for name, (old, new) in pairs.items():
                before[name]['commit'], after[name]['commit'] = old, new
            selected, archive = self.completed(root, 'A1')
            original = selected.read_bytes(), (archive / 'measurement.json').read_bytes()
            self.assertEqual(self.invoke(root, before, after), after)
            self.assertEqual(original, (selected.read_bytes(), (archive / 'measurement.json').read_bytes()))

    def test_silent_summary_update_does_not_allow_changed_input_parameters(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            before, after = self.records(root)
            before['Orca-A']['commit'] = '57a6ccc0b4a0ce21baa59081192bc8bb5f0208ba'
            after['Orca-A']['commit'] = 'c617ac3cfeb69a0dd32ca096ca53c8d62cbb6a83'
            after['Orca-A']['settings_sha256'] = 'changed-input'
            with self.assertRaises(ValueError):
                self.invoke(root, before, after)

    def test_one_click_rejects_old_or_modified_remote_before_allocating_instances(self):
        self.assertTrue(hasattr(matrix, 'require_prebuilt_remote'), 'Missing no-install runner preflight')
        with tempfile.TemporaryDirectory() as temporary:
            bench = Path(temporary)
            (bench / 'benchmark').mkdir()
            for content in ('def run(): install()\n', '# unknown runner\n'):
                (bench / 'benchmark/remote.py').write_text(content)
                with self.assertRaises(ValueError):
                    matrix.require_prebuilt_remote('Orca-A', bench)
            matrix.require_prebuilt_remote('Mysticeti', bench)


if __name__ == '__main__':
    unittest.main(verbosity=2)
