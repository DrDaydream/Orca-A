import csv
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import run_matrix as matrix
import plot_figures


class RuleReadyMatrixTests(unittest.TestCase):
    def archive(self, root, metric='release_to_rule_ready_ms', **extra):
        case = next(matrix.cases('Orca-A', 'A0'))
        folder = root / matrix.case_key(case)
        attempt = folder / 'attempt-1'
        attempt.mkdir(parents=True)
        matrix.save(folder / 'selected.json', dict(case=case, status='complete', attempt='attempt-1'))
        measurement = dict(case=case, status='complete', metric=metric, latency_ms=500,
                           final_latency_ms=3500, ready_to_final_ms=3000,
                           paired_ready_latency_ms=500, paired_final_latency_ms=3500,
                           latency_contributors=10, final_latency_contributors=10,
                           honest_replicas=10, zero_commit_replicas=[], zero_ready_replicas=[],
                           replicas=[])
        measurement.update(extra)
        matrix.save(attempt / 'measurement.json', measurement)
        return case

    def test_csv_retains_both_endpoints_and_paired_wait(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            case = self.archive(root)
            rows = plot_figures.export_data(root)
            row = next(r for r in rows if r['status'] == 'complete')
            self.assertEqual(row['latency_ms'], 500)
            self.assertEqual(row['final_latency_ms'], 3500)
            self.assertEqual(row['ready_to_final_ms'], 3000)
            with (root / 'measurements.csv').open(encoding='utf-8-sig') as handle:
                exported = next(r for r in csv.DictReader(handle) if r['status'] == 'complete')
            self.assertEqual(exported['metric'], 'release_to_rule_ready_ms')
            self.assertEqual(exported['paired_final_latency_ms'], '3500')

    def test_old_final_results_are_not_relabelled_as_ready(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.archive(root, metric='release_to_final_ms', final_latency_ms=None)
            row = next(r for r in plot_figures.export_data(root) if r['status'] == 'complete')
            self.assertIsNone(row['latency_ms'])
            self.assertEqual(row['latency_contributors'], 0)
            self.assertEqual(row['final_latency_ms'], 500)
            self.assertEqual(row['source_metric'], 'release_to_final_ms')

    def test_invalid_verification_latency_cannot_be_plotted(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.archive(root, final_latency_ms=-1)
            with self.assertRaisesRegex(ValueError, 'Invalid.*latency'):
                plot_figures.export_data(root)

    def test_main_and_verification_plots_use_their_own_endpoints(self):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from matplotlib.figure import Figure
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.archive(root)
            rows = plot_figures.export_data(root)
            for final, expected in [(False, 500), (True, 3500)]:
                with patch.object(Figure, 'savefig'), patch.object(plt, 'close'):
                    plot_figures.draw(rows, root / ('final' if final else 'ready'), final=final)
                    figure = plt.figure(plt.get_fignums()[0])
                    self.assertEqual(figure.axes[0].lines[0].get_ydata()[0], expected)
                plt.close('all')

    def test_main_latency_uses_ready_and_preserves_final_and_paired_wait(self):
        rows = [dict(authority=0, byzantine=False, completed=1, released=2,
                     latency_ms=600, final_latency_ms=3500, ready_to_final_ms=3000,
                     paired_ready_latency_ms=500, paired_final_latency_ms=3500,
                     rule_ready_samples=2)]
        result = matrix.summarize_replicas(rows)
        self.assertEqual(result['latency_ms'], 600)
        self.assertEqual(result['final_latency_ms'], 3500)
        self.assertEqual(result['ready_to_final_ms'], 3000)
        self.assertEqual(result['paired_final_latency_ms'] - result['paired_ready_latency_ms'], 3000)

    def test_replica_with_ready_but_no_final_is_a_main_metric_contributor(self):
        rows = [dict(authority=0, byzantine=False, completed=0, released=1,
                     latency_ms=200, final_latency_ms=None, ready_to_final_ms=None,
                     paired_ready_latency_ms=None, paired_final_latency_ms=None,
                     rule_ready_samples=1)]
        result = matrix.summarize_replicas(rows)
        self.assertEqual(result['latency_contributors'], 1)
        self.assertEqual(result['latency_ms'], 200)
        self.assertIsNone(result['final_latency_ms'])
        self.assertEqual(result['zero_ready_replicas'], [])
        self.assertEqual(result['zero_commit_replicas'], [0])


if __name__ == '__main__':
    unittest.main()
